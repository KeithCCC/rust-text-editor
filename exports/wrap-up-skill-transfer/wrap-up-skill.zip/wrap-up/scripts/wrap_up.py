#!/usr/bin/env python3
"""Create or update a dated project wrap-up Markdown log."""

from __future__ import annotations

import argparse
import datetime as dt
import os
import subprocess
from pathlib import Path


def run_git(args: list[str], cwd: Path) -> str:
    result = subprocess.run(
        ["git", *args],
        cwd=str(cwd),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if result.returncode != 0:
        return ""
    return result.stdout.strip()


def git_root(cwd: Path) -> Path | None:
    root = run_git(["rev-parse", "--show-toplevel"], cwd)
    return Path(root) if root else None


def fenced(value: str) -> str:
    return value.strip() if value.strip() else "(none)"


def main() -> int:
    parser = argparse.ArgumentParser(description="Create a daily project wrap-up log.")
    parser.add_argument("--date", default=dt.date.today().isoformat())
    parser.add_argument("--project-root", default=os.getcwd())
    args = parser.parse_args()

    cwd = Path(args.project_root).resolve()
    root = git_root(cwd) or cwd
    is_git = git_root(root) is not None

    log_dir = root / "docs" / "work-log"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / f"{args.date}.md"

    branch = run_git(["branch", "--show-current"], root) if is_git else ""
    status = run_git(["status", "--short"], root) if is_git else ""
    diff_stat = run_git(["diff", "--stat"], root) if is_git else ""
    staged_stat = run_git(["diff", "--cached", "--stat"], root) if is_git else ""
    recent = run_git(
        ["log", "--since", f"{args.date} 00:00", "--pretty=format:%h %s", "--max-count=20"],
        root,
    ) if is_git else ""

    content = f"""# Work Log - {args.date}

Project: `{root}`

## Summary

- TODO: Summarize today's work from the conversation and repository changes.

## Completed Work

- TODO

## Files Changed

```text
{fenced(status)}
```

## Verification

- TODO: List tests, builds, linting, manual checks, or note if not run.

## Follow-ups

- TODO

## Git Context

- Repository: {"yes" if is_git else "no"}
- Branch: `{branch or "n/a"}`

### Diff Stat

```text
{fenced(diff_stat)}
```

### Staged Diff Stat

```text
{fenced(staged_stat)}
```

### Today's Commits

```text
{fenced(recent)}
```

## Commit And Push

- Commit: TODO
- Push: TODO
"""

    if log_path.exists():
        existing = log_path.read_text(encoding="utf-8")
        marker = "\n## Git Context\n"
        if marker in existing:
            content = existing.split(marker, 1)[0].rstrip() + content[content.index(marker):]
        else:
            content = existing.rstrip() + "\n\n" + content

    log_path.write_text(content, encoding="utf-8")
    print(log_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
