---
name: wrap-up
description: Use when the user asks to wrap up, end the day, summarize today's project work, write a project Markdown log, or commit and push daily work.
---

# Wrap Up

## Overview

Finish the current project's work session by creating a dated Markdown log, then, when the directory is a Git repository, stage all changes, commit, and push.

## Workflow

1. Identify the project root from the current workspace. If it is inside a Git repo, use `git rev-parse --show-toplevel`; otherwise use the current working directory.
2. Collect today's work from the conversation, changed files, `git status --short`, `git diff --stat`, and recent commits. Use the user's timezone when known.
3. Run `scripts/wrap_up.py` to create or update `docs/work-log/YYYY-MM-DD.md` with Git context.
4. Edit the log so it contains a human-readable summary of what was done today, not only raw Git output.
5. If this is a Git repo, run the requested Git flow:
   - `git status --short`
   - inspect the log and status for obvious secrets or generated junk
   - `git add .`
   - `git commit -m "wrap-up: YYYY-MM-DD"`
   - `git push`; if no upstream exists, push with `git push -u origin <current-branch>`
6. Report the log path, commit hash, branch, and push result. If any Git step fails, report the failure and leave the repository state clear.

## Log Content

The Markdown log should include:

- Date and project path
- Summary
- Completed work
- Files changed
- Tests or verification performed
- Known follow-ups or risks
- Git status before commit
- Commit and push result when available

Prefer concise bullets. Do not invent completed work; if the conversation and Git data are insufficient, say what can be inferred from changed files.

## Git Rules

Follow the user's requested default: in a Git project, use `git add .`, commit, and push.

Before committing, still inspect `git status --short` and the diff summary. If there are obvious secrets, credentials, private keys, or unrelated destructive changes, stop and ask the user before staging. Otherwise proceed without asking.

Use a more specific commit message if today's work has a clear theme, for example `wrap-up: add billing export tests`. Otherwise use `wrap-up: YYYY-MM-DD`.

After a successful `git add .`, final responses in Codex Desktop must include the git stage directive. After a successful commit or push, include the matching git directives required by the app.

## Helper Script

Run from the project root:

```bash
python C:/Users/chien/.codex/skills/wrap-up/scripts/wrap_up.py --date YYYY-MM-DD
```

The script creates `docs/work-log/YYYY-MM-DD.md` and fills in Git context. Read and edit the generated file before committing.
